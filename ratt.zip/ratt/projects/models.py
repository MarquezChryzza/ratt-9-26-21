from django.db import models

# Create your models here.
class Converted(models.Model):
    Converted = models.TextField(max_length=200, null=True)