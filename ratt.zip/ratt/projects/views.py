from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import TemplateView

def projects(request):
    return render(request, 'projects/projects.html')

def project(request, pk):
    return render(request, 'projects/single-project.html')

# def upload(request):
#     if request.method == "POST":
#         upload_file = request.FILES['']
#     return render(request, 'main.html')
